package my.group.GradientBoostingRegression.gbrt;

public class Sample {
	public double[] a;

	public Sample(int n) {
		this.a = new double[n];
	}

	public Sample() {

	}
}
