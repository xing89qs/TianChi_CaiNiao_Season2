package my.group.GradientBoostingRegression.gbrt;

import java.util.Random;

import my.group.GradientBoostingRegression.gbrt.DecisionRegressionTree.Node;
import my.group.GradientBoostingRegression.gbrt.util.Estimator;
import my.group.GradientBoostingRegression.gbrt.util.LossFunction;
import my.group.GradientBoostingRegression.gbrt.util.QuantileEstimator;
import my.group.GradientBoostingRegression.gbrt.util.QuantileLossFunction;
import my.group.GradientBoostingRegression.gbrt.DecisionRegressionTree.TrainSample;;

public class GradientBoostingRegressor {

	private double learning_rate;
	private int n_estimator;
	private double alpha;
	private double subsample = 1.0;
	private Estimator init_;
	private LossFunction loss;
	private int random_state;
	private DecisionRegressionTree[] trees;
	private int max_depth;
	private double baseValue;
	private double[] residual;

	public GradientBoostingRegressor(double learning_rate, int n_estimator, int max_depth, double alpha) {
		this.learning_rate = learning_rate;
		this.n_estimator = n_estimator;
		this.max_depth = max_depth;
		this.trees = new DecisionRegressionTree[this.n_estimator];
		this.alpha = alpha;
		this.loss = new QuantileLossFunction(alpha);
		this.init_ = new QuantileEstimator(alpha);
		this.random_state = new Random().nextInt();
		for (int i = 0; i < MAX_SAMPLE; i++)
			samples[i] = new TrainSample(null, 0, 0);
	}

	private int MAX_SAMPLE = 50005;
	private TrainSample[] samples = new TrainSample[MAX_SAMPLE];
	private TrainSample[] sampleArrays = new TrainSample[MAX_SAMPLE];
	private double[] splitValueArray = new double[MAX_SAMPLE];
	private int[] randomArray = new int[MAX_SAMPLE];

	private double[] _fit_stage(int i, Sample[] X, double[] Y, double[] y_pred, double[] sample_weight) {
		this.loss.negative_gradient(Y, y_pred, this.residual);
		trees[i] = new DecisionRegressionTree(this.max_depth, this.random_state, samples, splitValueArray, sampleArrays,
				randomArray);
		trees[i].fit(X, residual, sample_weight);
		this.loss.update_terminal_region(trees[i], X, Y, y_pred, sample_weight);
		for (int j = 0; j < X.length; j++) {
			Node leaf = trees[i].apply(X[j]);
			y_pred[j] += learning_rate * leaf.treeVal;
		}
		return y_pred;
	}

	private int _fit_stages(Sample[] X, double[] Y, double[] y_pred, double[] sample_weight) {
		this.residual = new double[X.length];
		for (int i = 0; i < this.n_estimator; i++) {
			System.out.println("第" + i + "棵树");
			y_pred = _fit_stage(i, X, Y, y_pred, sample_weight);
		}
		return this.n_estimator;
	}

	public void fit(Sample[] X, double[] Y, double[] sample_weight) {
		this.init_.fit(X, Y, sample_weight);
		double[] y_pred = this.init_.predict(X);
		this.baseValue = y_pred[0];
		_fit_stages(X, Y, y_pred, sample_weight);
	}

	public double[] predict(Sample[] X) {
		double[] ans = new double[X.length];
		for (int i = 0; i < X.length; i++) {
			ans[i] = baseValue;
			for (int j = 0; j < n_estimator; j++) {
				DecisionRegressionTree.Node leaf = trees[j].apply(X[i]);
				ans[i] += learning_rate * leaf.treeVal;
			}
		}
		return ans;
	}

}
