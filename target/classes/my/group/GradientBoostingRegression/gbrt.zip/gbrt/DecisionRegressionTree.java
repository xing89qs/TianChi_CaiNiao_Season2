package my.group.GradientBoostingRegression.gbrt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Random;
import java.util.Stack;
import java.util.TreeSet;

import my.group.GradientBoostingRegression.gbrt.util.Utils;

public class DecisionRegressionTree {

	public static class Node {
		double split_val;
		int split_feature;
		public Node leftNode;
		public Node rightNode;
		public double treeVal;

		public ArrayList<Double> diff = new ArrayList<Double>();
		public ArrayList<Double> diff_sample_weight = new ArrayList<Double>();

		public void setTreeValue(double value) {
			this.treeVal = value;
		}

		public void clear() {
			this.diff.clear();
			this.diff.trimToSize();
			this.diff_sample_weight.clear();
			this.diff_sample_weight.trimToSize();
		}
	}

	private TreeSet<Double> distinctValues = new TreeSet<Double>();

	private final int MAX_SPLIT_VAL_NUM = 1000;

	private int max_depth;
	private int random_state;
	private Random random;
	private Node root;

	private TrainSample[] sampleArrays;

	public DecisionRegressionTree(int max_depth, int random_state, TrainSample[] samples, double[] splitValueArray,
			TrainSample[] sampleArrays, int[] randomArray) {
		this.max_depth = max_depth;
		this.random_state = random_state;
		this.random = new Random(this.random_state);
		this.samples = samples;
		this.sampleArrays = sampleArrays;
		this.splitValueArray = splitValueArray;
		this.randomArray = randomArray;
	}

	class SplitResult {
		Stack<TrainSample> leftSample, rightSample;
		double split_error, left_error, right_error;
		int best_feature;
		double best_split_val;

		// error = var_left + var_right
		// var_left = sigma((y_i-y_bar)^2*w)
		// = sigma(y_i*y_i*w_i)- y_bar*sigma(2*w_i*y_i)+ y_bar*y_bar*sigma(w_i)
		// y_bar = sigma(y_i*w_i)/sigma(w_i)

		double left_yyw_sum, left_y_w_sum, left_w_sum, left_bar;
		double right_yyw_sum, right_y_w_sum, right_w_sum, right_bar;

		public SplitResult(int l, int r, TrainSample[] samples) {
			leftSample = new Stack<TrainSample>();
			rightSample = new Stack<TrainSample>();
			init(l, r, samples);
		}

		void init(int l, int r, TrainSample[] samples) {
			this.split_error = Double.MAX_VALUE;
			leftSample.clear();
			rightSample.clear();

			left_yyw_sum = left_y_w_sum = left_w_sum = left_bar = 0;
			right_yyw_sum = right_y_w_sum = right_w_sum = right_bar = 0;
			for (int i = r; i >= l; i--) {
				rightSample.push(samples[i]);
				right_yyw_sum += samples[i].y * samples[i].y * samples[i].sample_weight;
				right_y_w_sum += samples[i].y * samples[i].sample_weight;
				right_w_sum += samples[i].sample_weight;
			}
			right_bar = right_y_w_sum / right_w_sum;
			left_error = left_yyw_sum - 2 * left_y_w_sum * left_bar + left_bar * left_bar * left_w_sum;
			right_error = right_yyw_sum - 2 * right_y_w_sum * right_bar + right_bar * right_bar * right_w_sum;
			split_error = left_error + right_error;
		}

		void moveSampleToLeft(int split_feature, double split_val) {
			while (!rightSample.empty()) {
				TrainSample sample = rightSample.peek();
				if (sample.X.a[split_feature] < split_val) {
					rightSample.pop();
					right_yyw_sum -= sample.y * sample.y * sample.sample_weight;
					right_y_w_sum -= sample.y * sample.sample_weight;
					right_w_sum -= sample.sample_weight;

					leftSample.push(sample);
					left_yyw_sum += sample.y * sample.y * sample.sample_weight;
					left_y_w_sum += sample.y * sample.sample_weight;
					left_w_sum += sample.sample_weight;
				} else
					break;
			}
			left_bar = left_y_w_sum / left_w_sum;
			right_bar = right_y_w_sum / right_w_sum;
			left_error = left_yyw_sum - 2 * left_y_w_sum * left_bar + left_bar * left_bar * left_w_sum;
			right_error = right_yyw_sum - 2 * right_y_w_sum * right_bar + right_bar * right_bar * right_w_sum;
			split_error = left_error + right_error;
		}

		Stack<TrainSample> getLeftTrainSamples() {
			return leftSample;
		}

		Stack<TrainSample> getRightTrainSamples() {
			return rightSample;
		}

	}

	private final int MAX_SAMPLE_NUM = 5000;

	private int[] randomArray;

	private SplitResult getBestSplit(int l, int r, TrainSample[] samples) {

		int n_features = samples[0].X.a.length;
		double min_split_error = Double.MAX_VALUE;
		int best_feature = -1;
		double best_split_val = Double.MAX_VALUE;

		int m = Math.min(r - l + 1, MAX_SAMPLE_NUM);
		Utils.sample(r - l + 1, m, randomArray);
		for (int i = 0; i < m; i++)
			this.sampleArrays[i] = samples[l + randomArray[i]];

		SplitResult currentResult = new SplitResult(0, m - 1, sampleArrays);
		for (int i = 0; i < n_features; i++) {
			if (random.nextDouble() > 0.8)
				continue;
			distinctValues.clear();
			for (int j = 0; j < m; j++)
				distinctValues.add(sampleArrays[j].X.a[i]);
			int cnt = 0;
			for (Double d : distinctValues)
				splitValueArray[cnt++] = d;
			if (cnt == 1)
				continue;
			for (int j = 0; j < cnt - 1; j++)
				splitValueArray[j] = (splitValueArray[j] + splitValueArray[j + 1]) / 2.0;
			cnt--;
			final int compareFeature = i;
			Arrays.sort(sampleArrays, 0, m, new Comparator<TrainSample>() {

				@Override
				public int compare(TrainSample o1, TrainSample o2) {
					return new Double(o1.X.a[compareFeature]).compareTo(o2.X.a[compareFeature]);
				}
			});
			currentResult.init(0, m - 1, sampleArrays);
			for (int j = 0; j < cnt; j++) {
				double split_val = splitValueArray[j];
				currentResult.moveSampleToLeft(i, split_val);
				if (currentResult.split_error < min_split_error) {
					min_split_error = currentResult.split_error;
					best_feature = i;
					best_split_val = split_val;
				}
			}
		}
		if (best_feature == -1)
			return null;
		final int compareFeature = best_feature;
		Arrays.sort(samples, l, r + 1, new Comparator<TrainSample>() {

			@Override
			public int compare(TrainSample o1, TrainSample o2) {
				return new Double(o1.X.a[compareFeature]).compareTo(o2.X.a[compareFeature]);
			}
		});

		SplitResult result = new SplitResult(l, r, samples);
		result.moveSampleToLeft(best_feature, best_split_val);
		result.best_feature = best_feature;
		result.best_split_val = best_split_val;
		return result;

	}

	private Node createTree(int l, int r, TrainSample[] samples, int depth) {
		if (depth > max_depth)
			return null;
		SplitResult result = getBestSplit(l, r, samples);
		Node root = new Node();
		if (result == null)
			return root;
		root.split_feature = result.best_feature;
		root.split_val = result.best_split_val;
		Stack<TrainSample> leftSamples = result.getLeftTrainSamples();
		Stack<TrainSample> rightSamples = result.getRightTrainSamples();
		int cnt = l;
		int leftSize = leftSamples.size();
		while (!leftSamples.empty())
			samples[cnt++] = leftSamples.pop();
		while (!rightSamples.empty())
			samples[cnt++] = rightSamples.pop();
		root.leftNode = createTree(l, l + leftSize - 1, samples, depth + 1);
		root.rightNode = createTree(l + leftSize, r, samples, depth + 1);
		return root;
	}

	static class TrainSample {
		public TrainSample(Sample sample, double d, double e) {
			this.init(sample, d, e);
		}

		Sample X;
		double y, sample_weight;

		public void init(Sample sample, double d, double e) {
			// TODO Auto-generated method stub

			this.X = sample;
			this.y = d;
			this.sample_weight = e;
		}
	}

	private TrainSample[] samples;
	private double splitValueArray[];

	public void fit(Sample[] X, double[] Y, double[] sample_weight) {
		random_state = random.nextInt();
		for (int i = 0; i < X.length; i++)
			samples[i].init(X[i], Y[i], sample_weight[i]);
		Node root = createTree(0, X.length - 1, samples, 0);
		this.root = root;
	}

	private Node dfs(Node root, Sample x) {
		if (root.leftNode == null)
			return root;
		if (x.a[root.split_feature] < root.split_val)
			return dfs(root.leftNode, x);
		return dfs(root.rightNode, x);
	}

	public Node apply(Sample x) {
		return dfs(root, x);
	}
}
