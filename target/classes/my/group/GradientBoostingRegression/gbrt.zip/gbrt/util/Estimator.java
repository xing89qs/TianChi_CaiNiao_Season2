package my.group.GradientBoostingRegression.gbrt.util;

import my.group.GradientBoostingRegression.gbrt.Sample;

public abstract class Estimator {
	public abstract void fit(Sample[] X, double[] y, double[] sample_weight);

	public abstract double[] predict(Sample[] X);
}
